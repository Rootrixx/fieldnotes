/**
 * contextSheetExport.ts
 *
 * Handles exporting a ContextSheet as:
 *  - PDF   – rendered HTML → expo-print → share
 *  - JPEG  – rendered PDF → expo-image-manipulator → share / save to Photos
 *  - CSV   – flat key/value rows → expo-file-system → share
 *
 * All formats land in the native share sheet (AirDrop, Mail, Files, etc.)
 * via expo-sharing.
 */

import { useState } from 'react';
import * as FileSystem from 'expo-file-system';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import * as ImageManipulator from 'expo-image-manipulator';

import type { ContextSheet, ContextSheetData } from '../types';
import { renderContextSheetHtml } from './contextSheetHtml';

export type ExportFormat = 'pdf' | 'jpeg' | 'csv';
export type ExportState = 'idle' | 'generating' | 'sharing' | 'done' | 'error';

// ---------------------------------------------------------------------------
// CSV helpers
// ---------------------------------------------------------------------------

function csvEscape(value: unknown): string {
  const str = Array.isArray(value)
    ? value.join('; ')
    : typeof value === 'boolean'
      ? value ? 'Yes' : 'No'
      : String(value ?? '');

  // Wrap in quotes if the value contains a comma, quote, or newline
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function flattenDataToCsvRows(data: ContextSheetData): [string, string][] {
  return [
    ['Site Name', data.site.name],
    ['Site Code', data.site.code],
    ['Context Number', data.contextNumber],
    ['Context Type', data.contextType],
    ['Trench', data.trench],
    ['Plan Number', data.planNumber],
    ['Section Number', data.sectionNumber],
    ['Coordinates', data.coordinates],
    ['Level', data.level],
    ['Description', data.description],
    ['Interpretation / Discussion', data.interpretationDiscussion],
    ['Overlain By', data.relationships.overlainBy.join('; ')],
    ['Abutted By', data.relationships.abuttedBy.join('; ')],
    ['Cut By', data.relationships.cutBy.join('; ')],
    ['Filled By', data.relationships.filledBy.join('; ')],
    ['Same As', data.relationships.sameAs.join('; ')],
    ['Part Of', data.relationships.partOf.join('; ')],
    ['Consists Of', data.relationships.consistsOf.join('; ')],
    ['Overlies', data.relationships.overlies.join('; ')],
    ['Butts', data.relationships.butts.join('; ')],
    ['Cuts', data.relationships.cuts.join('; ')],
    ['Fill Of', data.relationships.fillOf.join('; ')],
    ['Uncertain Relationship', data.relationships.uncertain],
    ['Temporal Above', data.temporalSequence.above.join('; ')],
    ['Temporal Current', data.temporalSequence.current],
    ['Temporal Below', data.temporalSequence.below.join('; ')],
    ['Finds – None', data.finds.none ? 'Yes' : ''],
    ['Finds – Pot', data.finds.pot ? 'Yes' : ''],
    ['Finds – Bone', data.finds.bone ? 'Yes' : ''],
    ['Finds – Flint', data.finds.flint ? 'Yes' : ''],
    ['Finds – Stone', data.finds.stone ? 'Yes' : ''],
    ['Finds – Burnt Stone', data.finds.burntStone ? 'Yes' : ''],
    ['Finds – Glass', data.finds.glass ? 'Yes' : ''],
    ['Finds – Metal', data.finds.metal ? 'Yes' : ''],
    ['Finds – CBM', data.finds.cbm ? 'Yes' : ''],
    ['Finds – Wood', data.finds.wood ? 'Yes' : ''],
    ['Finds – Leather', data.finds.leather ? 'Yes' : ''],
    ['Finds – Other', data.finds.other.join('; ')],
    ['Small Finds', data.smallFinds],
    ['Samples', data.samples],
    ['Building Materials', data.buildingMaterials],
    ['Additional Sheets', data.additionalSheets],
    ['Recorder', data.recorder],
    ['Date', data.date],
    ['Initials', data.initials],
  ];
}

function buildCsvString(sheet: ContextSheet): string {
  const rows = flattenDataToCsvRows(sheet.data);
  const header = 'Field,Value\n';
  const body = rows
    .map(([key, value]) => `${csvEscape(key)},${csvEscape(value)}`)
    .join('\n');
  return header + body;
}

// ---------------------------------------------------------------------------
// Fallback HTML for sheets without a stored template
// ---------------------------------------------------------------------------

function buildFallbackHtml(sheet: ContextSheet): string {
  const rows = flattenDataToCsvRows(sheet.data);
  const tableRows = rows
    .filter(([, value]) => value)
    .map(
      ([key, value]) =>
        `<tr><td class="key">${key}</td><td>${value.replace(/</g, '&lt;')}</td></tr>`
    )
    .join('\n');

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <style>
    body { font-family: Georgia, serif; font-size: 13px; color: #1a1008; margin: 24px; }
    h1 { font-size: 18px; margin-bottom: 4px; }
    .sub { color: #7a6557; font-size: 12px; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; }
    tr { border-bottom: 1px solid #e8ddd4; }
    td { padding: 6px 4px; vertical-align: top; }
    td.key { font-weight: bold; width: 40%; color: #5a4538; }
  </style>
</head>
<body>
  <h1>${sheet.title}</h1>
  <p class="sub">Context Sheet · ${sheet.data.site.code || ''} ${sheet.data.site.name || ''}</p>
  <table>${tableRows}</table>
</body>
</html>`;
}

// ---------------------------------------------------------------------------
// Safe filename helper
// ---------------------------------------------------------------------------

function safeFilename(title: string): string {
  return title.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 60);
}

// ---------------------------------------------------------------------------
// Core export functions
// ---------------------------------------------------------------------------

async function exportAsPdf(sheet: ContextSheet): Promise<void> {
  const html =
    renderContextSheetHtml(sheet.templateHtml, sheet.data) ?? buildFallbackHtml(sheet);

  const { uri } = await Print.printToFileAsync({ html, base64: false });

  const destUri = `${FileSystem.cacheDirectory}${safeFilename(sheet.title)}.pdf`;
  await FileSystem.moveAsync({ from: uri, to: destUri });

  await Sharing.shareAsync(destUri, {
    mimeType: 'application/pdf',
    dialogTitle: `Share ${sheet.title}`,
    UTI: 'com.adobe.pdf',
  });
}

async function exportAsJpeg(sheet: ContextSheet): Promise<void> {
  const html =
    renderContextSheetHtml(sheet.templateHtml, sheet.data) ?? buildFallbackHtml(sheet);

  // Render to PDF first, then convert page 1 to JPEG via ImageManipulator
  const { uri: pdfUri } = await Print.printToFileAsync({ html, base64: false });

  // expo-image-manipulator can read a PDF URI on iOS (treated as image)
  // On Android this may fall back to a blank image for complex PDFs —
  // acceptable for a v1 since JPEG is a best-effort format.
  const result = await ImageManipulator.manipulateAsync(
    pdfUri,
    [{ resize: { width: 1200 } }],
    { compress: 0.88, format: ImageManipulator.SaveFormat.JPEG }
  );

  // Clean up intermediate PDF
  await FileSystem.deleteAsync(pdfUri, { idempotent: true });

  const destUri = `${FileSystem.cacheDirectory}${safeFilename(sheet.title)}.jpg`;
  await FileSystem.moveAsync({ from: result.uri, to: destUri });

  await Sharing.shareAsync(destUri, {
    mimeType: 'image/jpeg',
    dialogTitle: `Share ${sheet.title}`,
    UTI: 'public.jpeg',
  });
}

async function exportAsCsv(sheet: ContextSheet): Promise<void> {
  const csv = buildCsvString(sheet);
  const destUri = `${FileSystem.cacheDirectory}${safeFilename(sheet.title)}.csv`;

  await FileSystem.writeAsStringAsync(destUri, csv, {
    encoding: FileSystem.EncodingType.UTF8,
  });

  await Sharing.shareAsync(destUri, {
    mimeType: 'text/csv',
    dialogTitle: `Share ${sheet.title}`,
    UTI: 'public.comma-separated-values-text',
  });
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useContextSheetExport() {
  const [exportState, setExportState] = useState<ExportState>('idle');
  const [exportError, setExportError] = useState<string | null>(null);

  async function exportSheet(sheet: ContextSheet, format: ExportFormat) {
    setExportState('generating');
    setExportError(null);

    try {
      if (format === 'pdf') {
        await exportAsPdf(sheet);
      } else if (format === 'jpeg') {
        await exportAsJpeg(sheet);
      } else {
        await exportAsCsv(sheet);
      }
      setExportState('done');
    } catch (err) {
      const message =
        err instanceof Error ? err.message : 'Export failed. Please try again.';
      setExportError(message);
      setExportState('error');
    } finally {
      // Reset after a short delay so the button can show feedback
      setTimeout(() => {
        setExportState('idle');
        setExportError(null);
      }, 3000);
    }
  }

  return { exportSheet, exportState, exportError };
}
